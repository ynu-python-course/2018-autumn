function fileTime(timestamp, tag) {
    if (tag === null || tag === '') tag = '编辑';
    let minute = 1000 * 60;
    let hour = minute * 60;
    let day = hour * 24;
    let month = day * 30;
    let now = new Date().getTime();
    let diffValue = now - timestamp;
    if (diffValue < 0) return '时间戳出错';
    let monthC = (diffValue / month>>0);
    let weekC = (diffValue / (7 * day)>>0);
    let dayC = (diffValue / day>>0);
    let hourC = (diffValue / hour>>0);
    let minC = (diffValue / minute>>0);
    if (monthC >= 1) return tag+"于" + monthC + "月前";
    else if (weekC >= 1) return tag+"于" + weekC + "周前";
    else if (dayC >= 1) return tag+"于" + dayC + "天前";
    else if (hourC >= 1) return tag+"于" + hourC + "小时前";
    else if (minC >= 1) return tag+"于" + minC + "分钟前";
    else return "刚刚"+tag;
}
