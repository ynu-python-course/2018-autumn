from django.shortcuts import render, render_to_response
from django.conf import settings
from django.views.decorators.csrf import csrf_protect
from LHBlog import utils
from blogmodel.models import Article

import os
# Create your views here.


def mainpage(request):
    data = {
        'blog_list': utils.get_blog_list(1),
        'blog_num':utils.get_blog_list(0),
        'pid': 1,
        'pre': '#',
        'next': 2,
    }
    return render(request, 'mainpage.html', data)


def page_not_found(request):
    return render_to_response('404.html')


def blog(request):
    blog_name = request.GET.get('bname', '')
    if not os.path.exists(os.path.join(settings.BLOG_DIR, blog_name+'.md')): return page_not_found(request)
    utils.get_blog_html(blog_name+'.md')
    data = {
        'blog': {
            'fn': blog_name,
            'fmt': int(os.path.getmtime(os.path.join(settings.BLOG_DIR, blog_name+'.md'))*1000),
            'fct': int(os.path.getctime(os.path.join(settings.BLOG_DIR, blog_name+'.md'))*1000),
            'html': utils.get_blog_html(blog_name+'.md')
        }
    }
    return render(request, 'blog.html', data)


def tool(request):
    return render(request,'tool.html')


@csrf_protect
def Upload(request):
    if request.method == "POST":    # 请求方法为POST时，进行处理
        myFile =request.FILES.get("myfile", None)    # 获取上传的文件，如果没有文件，则默认为None
        if not myFile:
            return render(request,'failure_upload.html')
        if myFile.size >1000000:
            return render(request,'failure_upload.html')

        article = Article(name=myFile.name,file=myFile)
        article.save()

        return render(request,'success_upload.html')
    else:
        return page_not_found(request)

        # destination = open(os.path.join('.\\md_data', myFile.name),'wb+')    # 打开特定的文件进行二进制的写操作
        # for chunk in myFile.chunks():      # 分块写入文件
        # destination.write(chunk)
        # destination.close()


def mainpage_id(request, id):
    data = {
        'blog_list': utils.get_blog_list(id=id),
        'blog_num': utils.get_blog_list(0),
        'pid':id,
        'pre': int(id)-1 if int(id) > 0 else 1,
        'next':int(id) + 1 if int(id) < len(utils.get_blog_list(0)[::5]) else 1
    }
    return render(request, 'mainpage.html', data)