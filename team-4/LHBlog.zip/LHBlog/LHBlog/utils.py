import os
from LHBlog.settings import BLOG_DIR
import markdown2
from bs4 import BeautifulSoup


BLOG_TEXT_MAX_LEN = 120


def get_blog_list(id):
    dir_files = os.listdir(BLOG_DIR)
    blog_list = []
    for fname in dir_files:
        if not fname.endswith('.md'): continue
        try:
            ftext = get_html_text(get_blog_html(fname))
        except UnicodeDecodeError:
            ftext = '文件编码错误'
        if len(ftext) > BLOG_TEXT_MAX_LEN: ftext = ftext[:BLOG_TEXT_MAX_LEN]+'...'
        blog_list.append({'fn': fname[:-3],
                          'fmt': int(os.path.getmtime(os.path.join(BLOG_DIR, fname))*1000),
                          'fct': int(os.path.getctime(os.path.join(BLOG_DIR, fname))*1000),
                          'brief': ftext})
    blog_list.sort(key=lambda x:x['fct'],reverse=True)
    if id == 0:
        return blog_list
    blog_list = blog_list[(int(id)-1)*5:int(id)*5]
    return blog_list


def get_blog_html(blog_name):
    with open(os.path.join(BLOG_DIR, blog_name), encoding='utf8') as bf:
        extras = ['code-friendly', 'fenced-code-blocks', 'footnotes', 'tables', 'task_list', 'cuddled-lists']
        try:
            md_text = bf.read()
            return markdown2.markdown(md_text, extras=extras)
        except UnicodeDecodeError:
            return markdown2.markdown('#文件编码错误', extras=extras)


def get_html_text(raw_html):
    bs = BeautifulSoup('<body>'+raw_html+'</body>', 'html.parser')
    return str(bs.find_all('body')[0].get_text())
