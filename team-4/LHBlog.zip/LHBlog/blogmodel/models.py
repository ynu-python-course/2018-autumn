from django.db import models
import os
# Create your models here.


class Contact(models.Model):
    name = models.CharField(max_length=50, null=False)
    email = models.EmailField()
    phone = models.CharField(max_length=50, null=True)
    time = models.DateField(auto_now=True)
    text = models.TextField()

    def __str__(self):
        return 'Name:' + str(self.name) + 'Email:' + str(self.email)


class Article(models.Model):
    name = models.CharField(max_length=50, null=False)
    time = models.DateField(auto_now=True)
    file = models.FileField(upload_to='md_data')

    def __str__(self):
        return 'Name:' + str(self.name) + 'Data:' + str(self.time)

    def delete(self, using=None, keep_parents=False):
        super().delete(using=None, keep_parents=False)
        if os.path.exists():
            os.remove(self.file.path)

