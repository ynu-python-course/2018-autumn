from django.apps import AppConfig


class BlogmodelConfig(AppConfig):
    name = 'blogmodel'
