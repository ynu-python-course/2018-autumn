from django.contrib import admin
from blogmodel.models import Contact, Article

# Register your models here.

admin.site.register(Contact)
admin.site.register(Article)
admin.site.site_header = 'Blog management system'
admin.site.site_title = 'LHBlog'
