from django.shortcuts import render
from blogmodel.models import Contact
from LHBlog.views import page_not_found
from django.views.decorators.csrf import csrf_protect


@csrf_protect
def contact(request):
    if request.method == "POST":    # 请求方法为POST时，进行处理

        email = request.POST.get("email_contact", None)
        name = request.POST.get("name_contact", None)
        phone = request.POST.get("phone_contact", None)
        text = request.POST.get("text_contact", None)

        if len(email) > 0 and len(name) > 0:
            if len(Contact.objects.filter(name=name,
                                       email=email, phone=phone)) > 0:
                return render(request, '../templates/contact_failure.html')
            c = Contact(email=email, name=name, phone=phone, text=text)
            c.save()
            return render(request, '../templates/contact_success.html')
        else:
            return render(request, '../templates/contact_failure.html')
    else:
        return page_not_found(request)

